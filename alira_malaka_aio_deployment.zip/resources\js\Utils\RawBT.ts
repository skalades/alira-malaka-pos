/**
 * Utility for generating ESC/POS commands and sending to RawBT
 */

export class EscPosBuilder {
    private buffer: Uint8Array = new Uint8Array(0);

    private append(data: number[] | Uint8Array) {
        const newData = data instanceof Uint8Array ? data : new Uint8Array(data);
        const combined = new Uint8Array(this.buffer.length + newData.length);
        combined.set(this.buffer);
        combined.set(newData, this.buffer.length);
        this.buffer = combined;
    }

    init() {
        this.append([0x1b, 0x40]); // ESC @
        return this;
    }

    alignCenter() {
        this.append([0x1b, 0x61, 0x01]); // ESC a 1
        return this;
    }

    alignLeft() {
        this.append([0x1b, 0x61, 0x00]); // ESC a 0
        return this;
    }

    alignRight() {
        this.append([0x1b, 0x61, 0x02]); // ESC a 2
        return this;
    }

    bold(on: boolean = true) {
        this.append([0x1b, 0x45, on ? 0x01 : 0x00]); // ESC E n
        return this;
    }

    fontSize(width: number = 1, height: number = 1) {
        // width and height can be 1-8
        const w = (width - 1) & 0x07;
        const h = (height - 1) & 0x07;
        const n = (w << 4) | h;
        this.append([0x1d, 0x21, n]); // GS ! n
        return this;
    }

    text(content: string) {
        const encoder = new TextEncoder();
        this.append(encoder.encode(content));
        return this;
    }

    line(content: string = '') {
        this.text(content + '\n');
        return this;
    }

    dashLine() {
        this.line('--------------------------------');
        return this;
    }

    feed(lines: number = 1) {
        for (let i = 0; i < lines; i++) {
            this.append([0x0a]); // LF
        }
        return this;
    }

    cut() {
        this.append([0x1d, 0x56, 0x42, 0x00]); // GS V 66 0
        return this;
    }

    toBase64() {
        let binary = '';
        const bytes = new Uint8Array(this.buffer);
        const len = bytes.byteLength;
        for (let i = 0; i < len; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        return window.btoa(binary);
    }
}

const justify = (left: string, right: string, width: number = 32): string => {
    const leftLen = left.length;
    const rightLen = right.length;
    const spaceNeeded = width - leftLen - rightLen;
    if (spaceNeeded <= 0) return left + ' ' + right;
    return left + ' '.repeat(spaceNeeded) + right;
};

export const printOrderRawBT = (order: any, shopSettings: any, taxSettings: any, mode: 'customer' | 'kitchen' | 'qc' = 'customer', category?: string) => {
    const builder = new EscPosBuilder().init();
    const pageWidth = 32; // Standard 58mm thermal printer characters per line

    if (mode === 'customer') {
        builder.alignCenter()
            .bold().fontSize(2, 2).line(shopSettings.name).fontSize(1, 1).bold(false)
            .line(shopSettings.address || '')
            .feed(1)
            .line('STRUK PELANGGAN')
            .line(new Date().toLocaleDateString('id-ID') + ' ' + new Date().toLocaleTimeString('id-ID'))
            .line(`Pesanan: #${order.order_number}`)
            .line(order.table ? `MEJA ${order.table.table_number}` : 'BUNGKUS')
            .dashLine()
            .alignLeft();

        order.order_items.forEach((item: any) => {
            const name = item.menu.name;
            const qty = `${item.quantity}x `;
            const price = (item.price_at_time * item.quantity).toLocaleString();
            
            // If name is too long, it will wrap naturally, but we want the price on the right of the first line
            // Simple approach: truncated name or intelligent wrap. 
            // Better: justify the first part of name + price
            const leftPart = qty + name;
            if (leftPart.length + price.length + 1 > pageWidth) {
                // Name too long, print name then price on next line justified
                builder.line(leftPart);
                builder.line(justify('', price, pageWidth));
            } else {
                builder.line(justify(leftPart, price, pageWidth));
            }
            
            if (item.notes) builder.line(`  * ${item.notes}`);
        });

        builder.dashLine();

        const subtotal = Number(order.total_price);
        if (taxSettings.enabled) {
            const tax = subtotal * taxSettings.percentage / 100;
            builder.line(justify('SUBTOTAL', subtotal.toLocaleString(), pageWidth));
            builder.line(justify(`PAJAK (${taxSettings.percentage}%)`, tax.toLocaleString(), pageWidth));
            builder.dashLine();
        }

        const total = taxSettings.enabled 
            ? subtotal + (subtotal * taxSettings.percentage / 100)
            : subtotal;

        builder.bold().line(justify('TOTAL TERTAGIH', `Rp ${total.toLocaleString()}`, pageWidth)).bold(false);

        if (order.transaction) {
            builder.feed(1)
                .line(justify(`BAYAR (${order.transaction.payment_method.toUpperCase()})`, Number(order.transaction.amount_paid).toLocaleString(), pageWidth))
                .bold().line(justify('KEMBALIAN', Number(order.transaction.change_amount).toLocaleString(), pageWidth)).bold(false);
        }

        builder.feed(2).alignCenter()
            .bold().line('--- TERIMA KASIH ---').bold(false)
            .line(shopSettings.footer || 'Selamat Menikmati')
            .feed(3).cut();
    } else if (mode === 'kitchen') {
        const categoryName = category || 'DAPUR';
        const items = order.order_items.filter((item: any) => {
            const itemCat = item.menu?.category?.name || 'DAPUR';
            return itemCat.toLowerCase() === categoryName.toLowerCase();
        });

        if (items.length === 0) return;

        builder.alignCenter()
            .bold().fontSize(2, 2).line(`TIKET ${categoryName.toUpperCase()}`).fontSize(1, 1).bold(false)
            .line(new Date().toLocaleDateString('id-ID') + ' ' + new Date().toLocaleTimeString('id-ID'))
            .line(`Pesanan: #${order.order_number}`)
            .line(order.table ? `MEJA ${order.table.table_number}` : 'BUNGKUS')
            .dashLine()
            .alignLeft();

        items.forEach((item: any) => {
            builder.bold().fontSize(2, 2).line(`${item.quantity}x ${item.menu.name}`).fontSize(1, 1).bold(false);
            if (item.notes) builder.line(`  Catatan: ${item.notes}`);
            builder.feed(1);
        });

        builder.feed(2).cut();
    } else if (mode === 'qc') {
        builder.alignCenter()
            .bold().fontSize(2, 2).line('QC CHECKLIST').fontSize(1, 1).bold(false)
            .line(new Date().toLocaleDateString('id-ID') + ' ' + new Date().toLocaleTimeString('id-ID'))
            .line(`Pesanan: #${order.order_number}`)
            .line(order.table ? `MEJA ${order.table.table_number}` : 'BUNGKUS')
            .dashLine()
            .alignLeft();

        order.order_items.forEach((item: any) => {
            builder.line(`[ ] ${item.quantity}x ${item.menu.name}`);
            if (item.notes) builder.line(`    * ${item.notes}`);
        });

        builder.feed(3).cut();
    }

    const base64 = builder.toBase64();
    const url = `rawbt:base64,${base64}`;

    // Detection for Android
    const isAndroid = /Android/i.test(navigator.userAgent);
    
    if (!isAndroid) {
        console.log('RawBT URL generated:', url);
        alert('Fitur "Cetak BT" (RawBT) hanya berfungsi di perangkat Android yang sudah terinstal aplikasi RawBT Driver.\n\nKarena Anda menggunakan Windows/Browser PC, data hanya ditampilkan di Console Log untuk pengecekan.');
        return;
    }

    window.location.href = url;
};
