<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ShiftController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

Route::get('/', function () {
    return redirect()->route('login');
});

Route::get('/demo', function () {
    return Inertia::render('Demo');
});

Route::get('/order/{table_number}', [\App\Http\Controllers\MenuController::class, 'index'])->name('order.index');
Route::post('/order/checkout', [\App\Http\Controllers\OrderController::class, 'store'])->name('order.checkout');

Route::middleware('auth')->group(function () {
    Route::get('/dashboard', function () {
        return Inertia::render('Dashboard');
    })->middleware(['verified', 'role:admin'])->name('dashboard');

    Route::middleware('role:cashier,admin')->group(function () {
        Route::get('/cashier', [\App\Http\Controllers\CashierController::class, 'index'])->name('cashier.index');
        Route::patch('/cashier/order/{order}/status', [\App\Http\Controllers\CashierController::class, 'updateStatus'])->name('cashier.order.status');
        Route::post('/cashier/order/{order}/pay', [\App\Http\Controllers\OrderController::class, 'pay'])->name('order.pay');

        // Shift Management
        Route::post('/shift/start', [ShiftController::class, 'start'])->name('shift.start');
        Route::post('/shift/end', [ShiftController::class, 'end'])->name('shift.end');
    });

    Route::prefix('admin')->name('admin.')->middleware('role:admin')->group(function () {
        Route::get('/', [\App\Http\Controllers\AdminController::class, 'dashboard'])->name('dashboard');
        Route::get('/menus', [\App\Http\Controllers\AdminController::class, 'menus'])->name('menus');
        
        // Category Management
        Route::post('/categories', [\App\Http\Controllers\AdminController::class, 'storeCategory'])->name('categories.store');
        Route::patch('/categories/{category}', [\App\Http\Controllers\AdminController::class, 'updateCategory'])->name('categories.update');
        Route::delete('/categories/{category}', [\App\Http\Controllers\AdminController::class, 'deleteCategory'])->name('categories.delete');

        // Menu Management
        Route::post('/menus', [\App\Http\Controllers\AdminController::class, 'storeMenu'])->name('menus.store');
        Route::post('/menus/{menu}', [\App\Http\Controllers\AdminController::class, 'updateMenu'])->name('menus.update'); // Using POST for multipart update
        Route::delete('/menus/{menu}', [\App\Http\Controllers\AdminController::class, 'deleteMenu'])->name('menus.delete');

        Route::post('/table/{table}/qr', [\App\Http\Controllers\AdminController::class, 'generateQR'])->name('table.qr');

        // Settings
        Route::get('/settings', [\App\Http\Controllers\AdminController::class, 'settings'])->name('settings');
        Route::post('/settings', [\App\Http\Controllers\AdminController::class, 'updateSettings'])->name('settings.update');

        // Reports
        Route::get('/reports', [\App\Http\Controllers\AdminController::class, 'reports'])->name('reports');
        Route::get('/reports/export', [\App\Http\Controllers\AdminController::class, 'exportPdf'])->name('reports.export');

        // Transactions History
        Route::get('/transactions', [\App\Http\Controllers\AdminController::class, 'transactions'])->name('transactions');
        Route::delete('/transactions/{transaction}', [\App\Http\Controllers\AdminController::class, 'deleteTransaction'])->name('transactions.delete');
    });

    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
