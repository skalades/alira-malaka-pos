<?php

namespace App\Http\Controllers;

use App\Events\OrderStatusUpdated;
use App\Models\Menu;
use App\Models\Order;
use App\Models\Table;
use Illuminate\Http\Request;
use Inertia\Inertia;

class CashierController extends Controller
{
    public function index()
    {
        $tables = Table::all();
        $menus = Menu::with('category')->where('is_available', true)->get();
        $pendingOrders = Order::with(['table', 'orderItems.menu.category', 'transaction'])
            ->whereIn('status', ['pending', 'processing', 'ready', 'paid'])
            ->latest()
            ->get();

        $dailyStats = [
            'revenue' => \App\Models\Transaction::whereDate('created_at', today())->sum('amount_paid') ?? 0,
            'orders' => Order::whereDate('created_at', today())->whereIn('status', ['paid', 'completed'])->count(),
        ];

        return Inertia::render('Cashier/Dashboard', [
            'tables' => $tables,
            'menus' => $menus,
            'pendingOrders' => $pendingOrders,
            'dailyStats' => $dailyStats,
            'activeShift' => \App\Models\Shift::where('user_id', auth()->id())
                ->where('status', 'open')
                ->first(),
            'taxSettings' => [
                'enabled' => \App\Models\Setting::get('tax_enabled', '0') === '1',
                'percentage' => (float)\App\Models\Setting::get('tax_percentage', '10'),
            ],
            'shopSettings' => [
                'name' => \App\Models\Setting::get('shop_name', 'ALIRA MALAKA'),
                'address' => \App\Models\Setting::get('shop_address', ''),
                'footer' => \App\Models\Setting::get('shop_footer', 'Terima Kasih!'),
            ]
        ]);
    }

    public function updateStatus(Request $request, Order $order)
    {
        $request->validate([
            'status' => 'required|in:pending,processing,ready,paid,completed,cancelled'
        ]);

        $order->update(['status' => $request->status]);

        if ($order->table && in_array($request->status, ['completed', 'cancelled'])) {
            $order->table->update(['status' => 'available']);
        }

        broadcast(new OrderStatusUpdated($order))->toOthers();

        return back()->with('success', 'Status pesanan berhasil diperbarui.');
    }
}
