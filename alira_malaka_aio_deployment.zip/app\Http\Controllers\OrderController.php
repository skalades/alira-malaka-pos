<?php

namespace App\Http\Controllers;

use App\Events\OrderPlaced;
use App\Models\Menu;
use App\Models\Order;
use App\Models\Table;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'table_id' => 'required_if:type,dine_in|nullable|exists:tables,id',
            'items' => 'required|array|min:1',
            'items.*.id' => 'required|exists:menus,id',
            'items.*.quantity' => 'required|integer|min:1',
            'items.*.notes' => 'nullable|string',
            'type' => 'nullable|in:dine_in,takeaway',
        ]);

        return DB::transaction(function () use ($request) {
            $table = $request->table_id ? Table::find($request->table_id) : null;

            $order = Order::create([
                'table_id' => $request->table_id,
                'order_number' => 'ORD-' . strtoupper(bin2hex(random_bytes(4))),
                'total_price' => 0,
                'status' => 'pending',
                'type' => $request->type ?? 'dine_in',
            ]);

            $totalPrice = 0;
            foreach ($request->items as $item) {
                $menu = Menu::findOrFail($item['id']);
                $priceAtTime = $menu->price;
                $subtotal = $priceAtTime * $item['quantity'];
                $totalPrice += $subtotal;

                $order->orderItems()->create([
                    'menu_id' => $menu->id,
                    'quantity' => $item['quantity'],
                    'price_at_time' => $priceAtTime,
                    'notes' => $item['notes'] ?? null,
                ]);
            }

            $order->update(['total_price' => $totalPrice]);
            if ($table) {
                $table->update(['status' => 'occupied']);
            }

            broadcast(new OrderPlaced($order))->toOthers();

            if ($request->user() && $request->type !== 'dine_in') {
                return back()->with([
                    'success' => 'Pesanan berhasil dibuat!',
                    'new_order' => $order
                ]);
            }

            $message = $order->type === 'dine_in' 
                ? 'Pesanan berhasil dikirim! Silakan ke kasir untuk melakukan konfirmasi agar pesanan dapat segera diproses.'
                : 'Pesanan berhasil dibuat!';

            return back()->with('success', $message);
        });
    }

    public function pay(Request $request, Order $order)
    {
        $shift = \App\Models\Shift::where('user_id', auth()->id())
            ->where('status', 'open')
            ->first();

        if (!$shift) {
            return back()->with('error', 'Silakan buka shift kasir terlebih dahulu sebelum memproses pembayaran.');
        }

        $taxEnabled = \App\Models\Setting::get('tax_enabled', '0') === '1';
        $taxPercentage = (float)\App\Models\Setting::get('tax_percentage', '10');
        $grandTotal = $taxEnabled 
            ? $order->total_price + ($order->total_price * $taxPercentage / 100) 
            : $order->total_price;

        $request->validate([
            'payment_method' => 'required|in:cash,qris,transfer',
            'amount_paid' => 'required|numeric|min:' . $grandTotal,
            'change_amount' => 'required|numeric|min:0',
        ]);

        return DB::transaction(function () use ($request, $order, $shift) {
            $order->transaction()->create([
                'shift_id' => $shift->id,
                'payment_method' => $request->payment_method,
                'amount_paid' => $request->amount_paid,
                'change_amount' => $request->change_amount,
                'transaction_time' => now(),
            ]);

            $order->update(['status' => 'paid']);
            
            broadcast(new \App\Events\OrderStatusUpdated($order))->toOthers();

            return back()->with('success', 'Pembayaran berhasil diproses!');
        });
    }
}
